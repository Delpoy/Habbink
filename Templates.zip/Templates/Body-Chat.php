<div class="container">
	<div class="row">
		<div class="col-md-8">
			<div class="panel panel-default">
				<div class="panel-heading blue">
					<h3 class="panel-title"><div class='contedor-badge'><div class='icon-news'></div></div> Chat</h3>
				</div>
				<div class="panel-body">
					<div class="eventotext">
						<center><embed wmode="transparent" src="http://www.xatech.com/web_gear/chat/chat.swf" quality="high" width="640" height="480" name="chat" flashvars="id=218304341" align="middle" allowscriptaccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://xat.com/update_flash.php"/>
						<br>
						<small><a target="_BLANK" href="http://xat.com/web_gear/chat/embed.php?id=218304341&GroupName=HabbinkFansite">Insertar codigo de chat</a> | <a target="_BLANK" href="http://xat.com/HabbinkFansite"> Página xat de Habbink</a></small><br>
						</center>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-4">
<?php echo $redes_sociales; ?>
			<?php echo $cartel_publicidad; ?>
		</div>
	</div>
</div>
<!-- /container -->