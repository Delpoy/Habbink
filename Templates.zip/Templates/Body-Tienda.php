<div class="container">
	<div class="row">
		<div class="col-md-8">
			<div class="panel panel-default">
				<div class="panel-heading green">
					<h3 class="panel-title"><div class='contedor-badge'><div class='icon-badges'></div></div> <?php echo $lang[41]; ?></h3>
				</div>
				<div class="panel-body">
				<?php
		$query = $link->query("SELECT * FROM tienda  order by id DESC");
		?>
<table class="table table-striped">
            <thead>
              <tr>
                <th></th>
                <th><?php echo $lang[42]; ?></th>
                <th><?php echo $lang[43]; ?></th>
                <th><?php echo $lang[44]; ?></th>
                <th><?php echo $lang[45]; ?></th>
                <th></th>
              </tr>
            </thead>
            <tbody>
		<?php
			while($row = mysqli_fetch_array($query)){

				$code_placa = $row['code_placa'];

				$placa_code = $link->query("SELECT * FROM placas WHERE code = '".$code_placa."'");
				while($placa = mysqli_fetch_array($placa_code)){
                $placa_img = $placa['imagen'];
                if ($row['icono'] == 'creditos') {
                	$icono = 'http://i.imgur.com/QpP3wav.png';
                }

                if ($row['icono'] == 'diamantes') {
                	$icono = 'http://i.imgur.com/2sjGOmJ.png';
                }
				}
?>
              <tr>
                <td></td>
                <td><img style="float:left;" src="<?php echo $placa_img; ?>" alt=""></td>
                <td><?php echo $code_placa; ?></td>
                <td><img src="<?php echo $icono; ?>" alt=""><?php echo $row['precio']; ?></td>
                <td><?php echo $row['unidades']; ?></td>
                <td><form class="form-horizontal" action="tienda.php" method="post" enctype="multipart/form-data"><input type="hidden" name="id_placa" value="<?php echo $row['id']; ?>"/><button type="submit" name="guardar" class="btn btn-primary"><?php echo $lang[46]; ?></button></form></td>
              </tr>
			<?php
			}
			?>
            </tbody>
          </table>

					  <?php
if (isset($_POST['guardar'])) {
	  if($_SESSION["logeado"] == "SI"){

				$tienda = $link->query("SELECT * FROM tienda WHERE id = '".$_POST[id_placa]."'");
				while($row = mysqli_fetch_array($tienda)){
                $placa_code = $row['code_placa'];
                $unidades = $row['unidades'];
                $precio = $row['precio'];
                $tipo = $row['icono'];
                }

				$datos_user = $link->query("SELECT * FROM usuarios WHERE username = '".$usuario_activo."'");
				while($row = mysqli_fetch_array($datos_user)){
                $creditos = $row['creditos'];
                $diamantes = $row['diamantes'];
                }

                if ($tipo == 'creditos') {
                	$dinero_user = $creditos;
                }

                if ($tipo == 'diamantes') {
                	$dinero_user = $diamantes;
                }

				$revisar = $link->query("SELECT * FROM usuarios_placas WHERE (username = '".$username."') AND (code_placa = '".$placa_code."')");
                $revisar1 = mysqli_num_rows($revisar);

				if ($unidades == '0') {
					echo "<div class='alert alerta-no alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>Ya no quedan unidades para comprar...</div>";
				} else {

                if ($precio >= $dinero_user) {
                	echo "<div class='alert alerta-no alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>Ha habido un problema alparecer no tienes suficiente $tipo</div>";
                } else {

                if ($revisar1 != '0') {
                	echo "<div class='alert alerta-no alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>Ya tienes esta placa en tu inventario</div>";
                } else {

	$fecha_log = date("Y-m-d");

$descuento = $dinero_user - $precio;
$descuento_unidad = $unidades - 1;

$consulta = "UPDATE tienda SET unidades='$descuento_unidad' WHERE id ='".$_POST[id_placa]."'";
$resultado = $link->query($consulta);

$consulta = "UPDATE usuarios SET $tipo='$descuento' WHERE username ='$usuario_activo'";
$resultado = $link->query($consulta);

$envio_placa = "INSERT INTO usuarios_placas (username,code_placa) values ('".$usuario_activo."','".strip_tags($placa_code)."')";

if ($link->query($envio_placa)) { 
  
// Guardar acción en Logs si se ha iniciado sesión
$accion = "Ha comprado una placa";
$enviar_log = "INSERT INTO logs (usuario,accion,fecha) values ('".$usuario_activo."','".$accion."','".$fecha_log."')";
$link->query($enviar_log);
// Log guardado en Base de datos
  
echo "<div class='alert alerta-si alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>Has comprado una placa correctamente</div>";
	  }else {
	echo "<div class='alert alerta-no alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>Ha habido un problema al realizar la compra...</div>";
}
}
}
}
  } else {
  	echo "<div class='alert alerta-no alert-dismissible'><button type='button' class='close' data-dismiss='alert'>×</button>Debes iniciar sesión para comprar una placa...</div>";
  } 
}
?>
				</div>
			</div>
		</div>
		<div class="col-md-4">
<?php echo $redes_sociales; ?>
			<?php echo $cartel_publicidad; ?>
		</div>
	</div>
	<script>
	$(document).ready(function(){
		load(1);
	});
	function load(page){
		var parametros = {"action":"ajax","page":page};
		$("#loader").fadeIn('slow');
		$.ajax({
			url:'kernel/ajax/Body_Tienda_ajax.php',
			data: parametros,
			 beforeSend: function(objeto){
			$("#loader").html("<img src='hk/loader.gif'>");
			},
			success:function(data){
				$(".outer_div").html(data).fadeIn('slow');
				$("#loader").html("");
			}
		})
	}
	</script>
</div>
<!-- /container -->