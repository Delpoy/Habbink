

<footer>
      <div class="container">
     	<div class="col-md-2" style="padding: 10px;"><center><img src="https://habtium.es/images/fansite_badge.gif"></center></div>
     	<div class="col-md-10"><h4><?php echo $lang[289]; ?></h4><?php echo $lang[290]; ?></div>
      </div>
    </footer>
      <div style="padding: 10px;background-color: #e9ebee;text-align: center;"><div class="container">&#169; Copyright 2017 <?php echo $nameweb; ?> <?php echo $lang[201]; ?> | Habbink cms v1.2 <?php echo $lang[202]; ?> <a class="footer1" href="https://www.facebook.com/profile.php?id=100004580028650">Matias Portales</a></div></div>
                  <script type="text/javascript">
                                        $(document).ready(function() {
                                            $('[data-toggle="tooltip"]').tooltip();
                                        });
                                    </script>
                                        <div style='visibility: hidden;display: none;position:absolute;'><script id='_wauxzi'>var _wau = _wau || []; _wau.push(['small', '<?php echo $contador ?>', 'xzi']);
(function() {var s=document.createElement('script'); s.async=true;
s.src='//widgets.amung.us/small.js';
document.getElementsByTagName('head')[0].appendChild(s);
})();</script></div>
	
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans" rel="stylesheet">

  <script type="text/javascript" src="ajax.js"></script>
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/cookieconsent2/1.0.10/cookieconsent.min.js"></script>
    <script src="<?php echo $url; ?>/styles/js/bootstrap.min.js"></script>
  </body>
</html>